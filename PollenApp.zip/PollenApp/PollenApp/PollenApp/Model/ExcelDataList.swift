//
//  ExcelDataList.swift
//  PollenAppSwiftUI
//
//  Created by Sabri Sönmez on 3/10/21.
//

import Foundation

struct ExcelDataList {
    var results: [String]
}
